<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Subscription extends Model
{
    /**
     * Pesquisar: não sei tabelas de resolução usam relacionamento 
     * belongsTo ou não possuem relacionamentos internos
     */

    #One to One relationships

    #One to Many relationships

    #Many to Many relationships
}
